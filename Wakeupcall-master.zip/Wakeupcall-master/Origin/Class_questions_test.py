import webbrowser
import os
import json
from Origin.Main import main

class questions:

    def question_1():
        while True:
            Choice_1 = input("""
            What do you want to do?

            1) WAKE ME UP!
            2) History settings (not available)
            3) music settings   (not available)

        (type the number that corresponds to your choice)
        """)
            if str(Choice_1).isalpha() == True or str(Choice_1) == "":
                print("""
        Please answer with 1
        """)
            elif int(Choice_1) in (1, 2, 3):
                return Choice_1
            else:
                print("""
        Please answer with 1
        """)

    def question_1_1():
        while True:
            Choice_1_1 = (input("""
            Choose your destination
            1) Bus Station
            2) Use history
            3) Choose your own destination

        """))
            if str(Choice_1_1).isalpha() == True or str(Choice_1_1) == "":
                print("""
        Please answer with 1,2 or 3
        """)
            elif int(Choice_1_1) in (1, 2, 3):
                return Choice_1_1
            else:
                print("""
        Please answer with 1,2 or 3
        """)

    def question_1_1_1():
        while True:
            Choice_1_1_1 = (input("""
        you will be shown a map with the available stations, please click the desired station and input the code that corresponds to it"
        would you like to proceed? [y/n]"""))
            Fl = Choice_1_1_1[0].lower()
            if Choice_1_1_1 == '' or not Fl in ['y', 'n']:
                print("""
        Please answer with yes or no!
        """)
            elif Fl == 'y':
                webbrowser.open_new_tab('Stations_map.html')
                with open("Stations_1.json") as data_file:
                    Destination = json.load(data_file)
                    Code = str(input("""
        please type in the numerical code
        """))
                    for item in Destination["Stations"]:
                        if Code in item["Codes"]:
                            destination = item[str(Code)]
                            return destination
                        else:
                            n = input("""
        cannot identify, press y to try again or press n to go back
        """)
                            if n == "n":
                                main()
            if Fl == 'n':
                main()

    def question_1_1_2():
        while True:
            if os.stat("History.json").st_size == 0:
                print("""
        your history is empty
        """)
                main()
            else:
                with open("History.json") as data_file:
                    Destination = json.load(data_file)
                    for item in Destination["coordinates"]:
                        print(item["name"])
                    Chosen_history = input("""
        Please type the wanted destination
        """)
            if str(Chosen_history) in item["name"]:
                destination = item[str(Chosen_history)]
                return destination
            else:
                n = input("""
        cannot identify, press y to try again or press n to go back
        """)
                if n == "n":
                    main()

    def question_1_1_3():
        Choice_1_1_3 = (input("""
            you will be shown a map, click anywhere to see the coordinates"
            would you like to proceed? [y/n]
        """))
        Fl = Choice_1_1_3[0].lower()
        if Choice_1_1_3 == '' or not Fl in ['y', 'n']:
            print("""
            Please answer with yes or no!
        """)
        elif Fl == 'y':
            webbrowser.open_new_tab('plain_map.html')
            lat = input("""
            please insert the numerical value of the lattitude
        """)
            long = input("""
            please insert the numerical value of the longitude
        """)
            return lat, long