import requests
import time
from playsound import playsound
import folium
import webbrowser
import os
import json
radius = 0.5 / 85.39


def executeGPS():
    res = requests.get('https://ipinfo.io/')
    data = res.json()

    location = data['loc'].split(',')
    Curlatitude = float(location[0])
    Curlongitude = float(location[1])

    print("Current Latitude : ", Curlatitude)
    print("Current Longitude : ", Curlongitude)

    return Curlatitude, Curlongitude


class Stations:
    stations = []
    def __init__(self, name,code, lat, long):
        self.code = code
        self.name = name
        self.lat = lat
        self.long = long
        Stations.stations.append(self)

    def check_if_in_radius(self,Curlat,Curlong):
        complete = "c"
        if ((((Curlat - self.lat) ** 2) + ((Curlong - self.long) ** 2)) <= radius ** 2):
            playsound('land on the horizon.mp3')
            return complete


s1 = Stations("France Square 1", 1, 40.187821, 44.514453)
s2 = Stations("France Square 2", 2, 40.187891, 44.515820)
s3 = Stations("France Square 3", 3, 40.1876707, 44.5160554)
s4 = Stations("Mesrop Mashtots 1", 4, 40.184753, 44.512428)
s5 = Stations("Mesrop Mashtots 2", 5, 40.1847592, 44.5119651)
s6 = Stations("Mesrop Mashtots 3", 6, 40.1813081, 44.507997)
s7 = Stations("Mesrop Mashtots 4", 7, 40.1813081,44.507997)
s8 = Stations("Mesrop Mashtots 5", 8, 40.1787796,44.5050988)
s9 = Stations("Mesrop Mashtots 6", 9, 40.1783644,44.5048064)
s10 = Stations("Kaskad", 10, 40.1881197,44.5154458)
s11 = Stations("Central bus station", 11, 40.1725216, 44.4732186)
s12 = Stations("Baghramyan", 12, 40.192003, 44.505178)



CureDes = executeGPS()
Curlatitude = float(CureDes[0])
Curlongitude = float(CureDes[1])


s12.check_if_in_radius(Curlatitude,Curlongitude)