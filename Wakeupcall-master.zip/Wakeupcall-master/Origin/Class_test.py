from Origin.Class_questions_test import question

q1 = question("""
What do you want to do?

1) WAKE ME UP!
2) History settings (not available)
3) music settings   (not available)

(type the number that corresponds to your choice)""")

q1_1 = question("""
Choose your destination

1) Bus Station
2) Use history
3) Choose your own destination""")

q1_1_1 = question("""
you will be shown a map with the available stations, please click the desired station and input the code that corresponds to it"
would you like to proceed? [y/n]""")


q1.answer_1()