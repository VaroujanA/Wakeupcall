# Wakeupcall
PRD Individual Project

1. Overview: Public transportations can be very tiring and time consuming, even more tiring when you didn’t have much time to sleep. Though getting those few minutes of shut-eye can be refreshing, sleeping in a public transport can be risky. This new app however may change those odds. Using a GPS system, you can draw a line on a map where it will trigger loud noises in your headphones when crossing it in the real world. Ultimately waking you up at the perfect moment. Because you will only draw a line on a map, it is easy to use.

2. Target Users: Who: people who use the public transport and don’t get enough sleep. What: this app will allow them to get a shut eye during their. When: when using the public transport. How: mobile app.

User Problem Solved: User need: time to sleep Resolution: this app will help people to fit in extra hours of sleep. User need: a way to sleep without accidently passing their station. Resolution: this app allows the users to choose a specific location that will wake them up when going pass it, helping them to wake up in time.

User Stories: As a user, I can open and choose a location for the alarm to go off. As a user, I can see public transportation stations and routes.
